﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OXGame
{
    public partial class Form1 : Form
    {
        Graphics g;
        Rectangle[] rt;
        string[,] str_puzzle = new string[3,3];
        Bitmap b1, b2, b3;
        string str1 = "o", str2 = "x";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            Bitmap bpp;
            string strTemp;
            if (rt[0].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[0]); str_puzzle[0, 0] = str1; }
            if (rt[1].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[1]); str_puzzle[0, 1] = str1; }
            if (rt[2].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[2]); str_puzzle[0, 2] = str1; }
            if (rt[3].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[3]); str_puzzle[1, 0] = str1; }
            if (rt[4].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[4]); str_puzzle[1, 1] = str1; }
            if (rt[5].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[5]); str_puzzle[1, 2] = str1; }
            if (rt[6].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[6]); str_puzzle[2, 0] = str1; }
            if (rt[7].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[7]); str_puzzle[2, 1] = str1; }
            if (rt[8].Contains(e.X, e.Y)) { g.DrawImage(b2, rt[8]); str_puzzle[2, 2] = str1; }

            bpp = b2; b2 = b3; b3 = bpp;
            strTemp = str1; str1 = str2; str2 = strTemp;

            if (isWin())
            {
                if (MessageBox.Show("Та дахин эхлүүлэх үү?", "Тоглоом дууслаа", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    NewGame();
                }
                else
                {
                    this.Close();
                }
            }

        }

        private bool isWin()
        {
            bool bl = false;
            if (str_puzzle[0, 0] + str_puzzle[0, 1] + str_puzzle[0, 2] == "ooo" || str_puzzle[0, 0] + str_puzzle[0, 1] + str_puzzle[0, 2] == "xxx") bl = true;
            if (str_puzzle[1, 0] + str_puzzle[1, 1] + str_puzzle[1, 2] == "ooo" || str_puzzle[1, 0] + str_puzzle[1, 1] + str_puzzle[1, 2] == "xxx") bl = true;
            if (str_puzzle[2, 0] + str_puzzle[2, 1] + str_puzzle[2, 2] == "ooo" || str_puzzle[2, 0] + str_puzzle[2, 1] + str_puzzle[2, 2] == "xxx") bl = true;
            return bl;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            NewGame();
            b1 = new Bitmap("pic01.jpg"); // bg
            b2 = new Bitmap("pic02.jpg"); // x
            b3 = new Bitmap("pic03.jpg"); // o

            g = this.CreateGraphics();
            rt = new Rectangle[9];
            rt[0] = new Rectangle(79, 60, 85, 85);
            rt[1] = new Rectangle(170, 60, 85, 85);
            rt[2] = new Rectangle(261, 60, 85, 85);
            rt[3] = new Rectangle(79, 151, 85, 85);
            rt[4] = new Rectangle(170, 151, 85, 85);
            rt[5] = new Rectangle(261, 151, 85, 85);
            rt[6] = new Rectangle(79, 242, 85, 85);
            rt[7] = new Rectangle(170, 242, 85, 85);
            rt[8] = new Rectangle(261, 242, 85, 85);
        }

        private void NewGame()
        {
            str_puzzle[0, 0] = "k";
            str_puzzle[0, 1] = "k";
            str_puzzle[0, 2] = "k";

            str_puzzle[1, 0] = "k";
            str_puzzle[1, 1] = "k";
            str_puzzle[1, 2] = "k";

            str_puzzle[2, 0] = "k";
            str_puzzle[2, 1] = "k";
            str_puzzle[2, 2] = "k";
            Invalidate();
        }

    }
}
